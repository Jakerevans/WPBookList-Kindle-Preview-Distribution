<?php

/**
 * Verifies that the core WPBookList plugin is installed and activated - otherwise, the Extension doesn't load and a message is displayed to the user.
 */
function wpbooklist_kindlepreview_core_plugin_required() {

    // Require core WPBookList Plugin.
    if ( ! is_plugin_active( 'wpbooklist/wpbooklist.php' ) && current_user_can( 'activate_plugins' ) ) {

        // Stop activation redirect and show error.
        wp_die( 'Whoops! This WPBookList Extension requires the Core WPBookList Plugin to be installed and activated! <br><a target="_blank" href="https://wordpress.org/plugins/wpbooklist/">Download WPBookList Here!</a><br><br><a href="' . admin_url( 'plugins.php' ) . '">&laquo; Return to Plugins</a>');
    }
}

// Adding the front-end ui css file for this extension
function wpbooklist_jre_kindlepreview_frontend_ui_style() {
    wp_register_style( 'wpbooklist-kindlepreview-frontend-ui', kindlepreview_ROOT_CSS_URL.'kindlepreview-frontend-ui.css' );
    wp_enqueue_style('wpbooklist-kindlepreview-frontend-ui');
}

// Code for adding the general admin CSS file
function wpbooklist_jre_kindlepreview_admin_style() {
  if(current_user_can( 'administrator' )){
      wp_register_style( 'wpbooklist-kindlepreview-admin-ui', kindlepreview_ROOT_CSS_URL.'kindlepreview-admin-ui.css');
      wp_enqueue_style('wpbooklist-kindlepreview-admin-ui');
  }
}


add_filter('wpbooklist_add_to_library_display_options_kindle', 'wpbooklist_add_to_library_display_options_kindle_func');

function wpbooklist_add_to_library_display_options_kindle_func($string) {


$string1 = '<tr>
            <td><label>Hide Kindle Preview</label></td>
            <td class="wpbooklist-margin-right-td"><input type="checkbox" name="hide-frontend-kindle-preview"';

            $string2 = '';
            if($string != null && $string != 0){
            	$string2 = esc_attr('checked="checked"');
            }


            $string3 = '></input></td>
            </tr>';

	return $string1.$string2.$string3;
}

add_filter('wpbooklist_add_to_library_display_options_post_kindle', 'wpbooklist_add_to_library_display_options_post_kindle_func');

function wpbooklist_add_to_library_display_options_post_kindle_func($string) {


$string1 = '<tr>
            <td><label>Hide Kindle Preview</label></td>
            <td class="wpbooklist-margin-right-td"><input type="checkbox" name="hide-frontend-kindle-preview"';

            $string2 = '';
            if($string != null && $string != 0){
            	$string2 = esc_attr('checked="checked"');
            }


            $string3 = '></input></td>
            </tr>';

	return $string1.$string2.$string3;
}

add_filter('wpbooklist_add_to_library_display_options_page_kindle', 'wpbooklist_add_to_library_display_options_page_kindle_func');

function wpbooklist_add_to_library_display_options_page_kindle_func($string) {


$string1 = '<tr>
            <td><label>Hide Kindle Preview</label></td>
            <td class="wpbooklist-margin-right-td"><input type="checkbox" name="hide-frontend-kindle-preview"';

            $string2 = '';
            if($string != null && $string != 0){
            	$string2 = esc_attr('checked="checked"');
            }


            $string3 = '></input></td>
            </tr>';

	return $string1.$string2.$string3;
}




add_filter('wpbooklist_add_to_colorbox_kindle', 'wpbooklist_add_to_colorbox_kindle_func');

function wpbooklist_add_to_colorbox_kindle_func($string) {

	//$r = file_get_contents('https://read.amazon.com/kp/card?asin='.$string[0].'&linkCode=kpe&ref_=cm_sw_r_kb_dp_9WxVzbWFMP2KQ&tag='.$string[1]);




	$string1 = '<p class="wpbooklist_description_p" id="wpbooklist-kindle-title-id">Kindle Preview:</p><div class="wpbooklist_kindle_p_class">';
	$string2 = '<iframe class="kp-bookcard-inline-reader" width="100%" height="100%" allowfullscreen="true" type="text/html" src="https://read.amazon.com/kp/embed?asin='.$string[0].'&linkCode=kpe&tag='.$string[1].'&preview=inline&from=Bookcard" ></iframe></div>';
	return $string1.$string2;
}


add_filter('wpbooklist_add_to_page_kindle', 'wpbooklist_add_to_page_kindle_func');

function wpbooklist_add_to_page_kindle_func($string) {
	$string1 = '<p style="font-weight:bold; font-size:18px; margin-bottom:5px;" class="wpbl-pagetd-share-text">Kindle Preview</p><div class="wpbooklist_kindle_page_post_class">';
	$string2 = '<iframe type="text/html" src="https://read.amazon.com/kp/card?asin='.$string[0].'&linkCode=kpe&ref_=cm_sw_r_kb_dp_9WxVzbWFMP2KQ&tag='.$string[1].'" ></iframe></div>';
	return $string1.$string2;
}

add_filter('wpbooklist_add_to_post_kindle', 'wpbooklist_add_to_post_kindle_func');

function wpbooklist_add_to_post_kindle_func($string) {
	$string1 = '<p style="font-weight:bold; font-size:18px; margin-bottom:5px;" class="wpbl-posttd-share-text">Kindle Preview</p><div class="wpbooklist_kindle_page_post_class">';
	$string2 = '<iframe type="text/html" src="https://read.amazon.com/kp/card?asin='.$string[0].'&linkCode=kpe&ref_=cm_sw_r_kb_dp_9WxVzbWFMP2KQ&tag='.$string[1].'" ></iframe></div>';
	return $string1.$string2;
}




?>